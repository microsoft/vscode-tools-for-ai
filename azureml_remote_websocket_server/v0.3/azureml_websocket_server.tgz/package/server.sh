#!/usr/bin/env sh
#
# Copyright (c) Microsoft Corporation. All rights reserved.
#

case "$1" in
	--inspect*) shift;;
esac

ROOT="$(dirname "$0")"

exec "$ROOT/azureml-websocket-server" "$@"
